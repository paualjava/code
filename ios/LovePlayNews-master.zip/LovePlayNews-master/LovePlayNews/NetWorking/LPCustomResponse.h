//
//  LPCustomResponse.h
//  LovePlayNews
//
//  Created by tany on 16/8/23.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPResponseObject.h"

@interface LPCustomResponse : LPResponseObject

@end
