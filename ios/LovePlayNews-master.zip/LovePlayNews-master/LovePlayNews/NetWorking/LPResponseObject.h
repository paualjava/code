//
//  TYResponseObject.h
//  TYHttpManagerDemo
//
//  Created by tany on 16/5/24.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "TYResponseObject.h"

typedef NS_ENUM(NSInteger, TYStauteCode) {
    TYStauteSuccessCode = 0,
};

@interface LPResponseObject : TYResponseObject

@end
