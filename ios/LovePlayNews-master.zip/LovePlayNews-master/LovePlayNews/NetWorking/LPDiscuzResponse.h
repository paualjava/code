//
//  LPDiscuzResponse.h
//  LovePlayNews
//
//  Created by tany on 16/9/7.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "TYResponseObject.h"

@interface LPDiscuzResponse : TYResponseObject

@end
