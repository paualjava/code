//
//  NSData+Base64.h
//  TYFoundationDemo
//
//  Created by tanyang on 15/12/22.
//  Copyright © 2015年 tanyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (ty_Parameters)

- (NSString*)parametersString;
- (NSString*)orderedParametersString;

@end
