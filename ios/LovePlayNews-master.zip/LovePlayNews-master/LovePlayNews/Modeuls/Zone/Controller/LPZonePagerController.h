//
//  LPZonePagerController.h
//  LovePlayNews
//
//  Created by tanyang on 16/9/4.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "TYTabButtonPagerController.h"

@interface LPZonePagerController : TYTabButtonPagerController

@end
