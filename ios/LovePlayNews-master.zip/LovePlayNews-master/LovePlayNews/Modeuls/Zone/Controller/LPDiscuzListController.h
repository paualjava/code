//
//  LPDiscuzListController.h
//  LovePlayNews
//
//  Created by tany on 16/9/7.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface LPDiscuzListController : ASViewController

@property (nonatomic, strong) NSString *fid;

@end
