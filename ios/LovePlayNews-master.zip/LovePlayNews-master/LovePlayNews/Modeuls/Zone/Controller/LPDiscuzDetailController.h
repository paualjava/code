//
//  LPDiscuzDetailController.h
//  LovePlayNews
//
//  Created by tanyang on 16/9/8.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPDiscuzDetailController : UIViewController

@property (nonatomic, strong) NSString *tid;

@end
