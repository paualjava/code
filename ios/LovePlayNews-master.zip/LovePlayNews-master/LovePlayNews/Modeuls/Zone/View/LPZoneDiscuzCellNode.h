//
//  LPDiscuzCellNode.h
//  LovePlayNews
//
//  Created by tany on 16/9/5.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>
#import "LPZoneDiscuzModel.h"

@interface LPZoneDiscuzCellNode : ASCellNode

- (instancetype)initWithItem:(LPZoneDiscuzItem *)item;

@end
