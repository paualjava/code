//
//  LPNewsCommentController.h
//  LovePlayNews
//
//  Created by tanyang on 16/8/20.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface LPNewsCommentController : ASViewController

@property (nonatomic, strong) NSString *newsId;

@end
