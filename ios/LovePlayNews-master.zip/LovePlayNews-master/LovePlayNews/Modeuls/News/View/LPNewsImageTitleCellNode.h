//
//  LPNewsImageTitleCellNode.h
//  LovePlayNews
//
//  Created by tany on 16/8/30.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPNewsBaseCellNode.h"

@interface LPNewsImageTitleCellNode : LPNewsBaseCellNode

@end
