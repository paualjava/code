//
//  LPNewsTitleSectionView.h
//  LovePlayNews
//
//  Created by tany on 16/8/11.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPNewsTitleSectionView : UITableViewHeaderFooterView

@property (nonatomic, strong) NSString *title;

@end
