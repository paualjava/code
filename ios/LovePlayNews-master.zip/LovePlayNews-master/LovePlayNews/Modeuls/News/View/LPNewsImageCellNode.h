//
//  LPNewsImageCellNode.h
//  LovePlayNews
//
//  Created by tany on 16/8/12.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPNewsBaseCellNode.h"

@interface LPNewsImageCellNode : LPNewsBaseCellNode

@end
