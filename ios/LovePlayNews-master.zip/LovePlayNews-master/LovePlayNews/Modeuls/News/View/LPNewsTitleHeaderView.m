//
//  LPNewsTitleHeaderView.m
//  LovePlayNews
//
//  Created by tany on 16/8/10.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPNewsTitleHeaderView.h"

@interface LPNewsTitleHeaderView ()

@end

@implementation LPNewsTitleHeaderView

- (void)awakeFromNib
{
    [super awakeFromNib];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
