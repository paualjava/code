//
//  LPNewsCellNode.h
//  LovePlayNews
//
//  Created by tany on 16/8/4.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPNewsBaseCellNode.h"

@interface LPNewsCellNode : LPNewsBaseCellNode

@end
