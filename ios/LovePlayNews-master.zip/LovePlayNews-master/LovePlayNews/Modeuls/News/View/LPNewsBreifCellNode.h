//
//  LPNewsBreifCellNode.h
//  LovePlayNews
//
//  Created by tany on 16/8/11.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface LPNewsBreifCellNode : ASCellNode

- (instancetype)initWithBreif:(NSString *)breif;

@end
