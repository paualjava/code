//
//  LPNewsReplayCollectNode.h
//  LovePlayNews
//
//  Created by tany on 16/8/19.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface LPNewsReplyCollectNode : ASDisplayNode

- (instancetype)initWithCommentItems:(NSDictionary *)commentItems floors:(NSArray *)floors;

@end
