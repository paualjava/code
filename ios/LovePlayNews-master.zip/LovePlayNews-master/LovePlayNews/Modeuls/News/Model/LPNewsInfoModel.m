//
//  LPNewsInfoModel.m
//  LovePlayNews
//
//  Created by tany on 16/8/3.
//  Copyright © 2016年 tany. All rights reserved.
//

#import "LPNewsInfoModel.h"

@implementation LPNewsInfoModel

@end
