//
//  LPTopicImageInfo.h
//  LovePlayNews
//
//  Created by tany on 16/8/26.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPTopicImageInfo : NSObject

@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *docid;
@property (nonatomic, strong) NSString *imgUrl;
@property (nonatomic, strong) NSString *priority;
@property (nonatomic, strong) NSString *title;

@end
