//
//  LPGameNewsController.h
//  LovePlayNews
//
//  Created by tany on 16/8/29.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface LPGameNewsController : ASViewController

@property (nonatomic, strong) NSString *newsTopId;
@property (nonatomic, assign) NSInteger sourceType;
@end
