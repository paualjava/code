//
//  LPMineViewController.h
//  LovePlayNews
//
//  Created by tanyang on 16/9/5.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPMineViewController : UIViewController

@end
