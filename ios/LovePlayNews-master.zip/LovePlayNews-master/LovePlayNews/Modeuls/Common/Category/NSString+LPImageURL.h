//
//  NSString+LPImageURL.h
//  LovePlayNews
//
//  Created by tany on 16/9/2.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (LPImageURL)

- (NSURL *)appropriateImageURL;

- (NSString *)appropriateImageURLSting;

@end
