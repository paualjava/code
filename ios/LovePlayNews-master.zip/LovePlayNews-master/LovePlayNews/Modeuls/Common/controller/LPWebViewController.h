//
//  LPWebViewController.h
//  LovePlayNews
//
//  Created by tany on 16/8/11.
//  Copyright © 2016年 tany. All rights reserved.
//

#import <TOWebViewController/TOWebViewController.h>

@interface LPWebViewController : TOWebViewController

@end
