//
//  Class_Basic.h
//  LovePlayNews
//
//  Created by tany on 16/8/30.
//  Copyright © 2016年 tany. All rights reserved.
//

#ifndef Class_Basic_h
#define Class_Basic_h

#ifdef __OBJC__

#import <UIKit/UIKit.h>
#import "UIView+Nib.h"
#import "NSString+LPImageURL.h"

#endif

#endif /* Class_Basic_h */
