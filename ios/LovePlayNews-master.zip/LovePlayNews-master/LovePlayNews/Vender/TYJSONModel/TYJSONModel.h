//
//  TYJSONModel.h
//  TYJSONModelDemo
//
//  Created by tany on 16/4/8.
//  Copyright © 2016年 tany. All rights reserved.
//

#ifndef TYJSONModel_h
#define TYJSONModel_h

#import "NSObject+TYJSONModel.h"
#import "TYClassInfo.h"

#endif /* TYJSONModel_h */
