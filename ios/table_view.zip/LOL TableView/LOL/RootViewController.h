//
//  RootViewController.h
//  LOL
//
//  Created by MagicStudio on 12-9-15.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController
{
    NSMutableArray *heroData;
    NSMutableArray *heroSections;
}

- (void) createHeroData;

@end
