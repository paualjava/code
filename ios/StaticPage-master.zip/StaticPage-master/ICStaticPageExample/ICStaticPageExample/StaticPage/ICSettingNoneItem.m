//
//  ICSettingNoneItem.m
//  ICStaticPage
//
// github地址:https://github.com/corderguo/StaticPage
//
//  Created by Mr.Guo on 15/5/28.
//  Copyright © 2016年 XianZhuangGuo. All rights reserved.
//

#import "ICSettingNoneItem.h"

@implementation ICSettingNoneItem

@end
