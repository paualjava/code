//
//  ICSettingSwitchItem.h
//  ICStaticPage
//
// github地址:https://github.com/corderguo/StaticPage
//
//  Created by Mr.Guo on 15/5/28.
//  Copyright © 2016年 XianZhuangGuo. All rights reserved.
//

#import "ICCommonItem.h"

@interface ICSettingSwitchItem : ICCommonItem

@end
