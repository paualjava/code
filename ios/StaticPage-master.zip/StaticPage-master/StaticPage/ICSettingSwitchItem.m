//
//  ICSettingSwitchItem.m
//  ICStaticPage
//
//  Created by Mr.Guo on 15/5/28.
//  Copyright © 2016年 XianZhuangGuo. All rights reserved.
//

#import "ICSettingSwitchItem.h"

@implementation ICSettingSwitchItem

@end
