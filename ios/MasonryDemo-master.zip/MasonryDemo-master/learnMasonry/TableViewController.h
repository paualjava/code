//
//  TableViewController.h
//  learnMasonry
//
//  Created by huangyibiao on 15/11/28.
//  Copyright © 2015年 huangyibiao. All rights reserved.
//

#import "HYBBaseController.h"


@interface TableViewController : HYBBaseController

@end
