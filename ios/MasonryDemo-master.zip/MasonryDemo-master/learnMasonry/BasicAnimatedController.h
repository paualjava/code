//
//  BasicAnimatedController.h
//  learnMasonry
//
//  Created by huangyibiao on 15/11/27.
//  Copyright © 2015年 huangyibiao. All rights reserved.
//

#import "HYBBaseController.h"

@interface BasicAnimatedController : HYBBaseController

@end
