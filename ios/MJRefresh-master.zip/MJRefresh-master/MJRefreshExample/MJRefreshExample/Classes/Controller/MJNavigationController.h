//
//  MJNavigationController.h
//  快速集成下拉刷新
//
//  Created by apple on 13-12-23.
//  Copyright (c) 2013年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJNavigationController : UINavigationController

@end
