//
//  PRAppearanceTableView.h
//  PlainReader
//
//  Created by guojiubo on 11/24/14.
//  Copyright (c) 2014 guojiubo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PRTableView : UITableView

@end
