//
//  main.m
//  CYWebviewController
//
//  Created by 万鸿恩 on 07/12/2016.
//  Copyright (c) 2016 万鸿恩. All rights reserved.
//

@import UIKit;
#import "CYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CYAppDelegate class]));
    }
}
