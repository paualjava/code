//
//  CYAppDelegate.h
//  CYWebviewController
//
//  Created by 万鸿恩 on 07/12/2016.
//  Copyright (c) 2016 万鸿恩. All rights reserved.
//

@import UIKit;

@interface CYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
